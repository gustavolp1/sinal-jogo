# sinal-jogo
Um jogo estilo "Termo" ou "Wordle" com foco em usuários surdos.

Para rodar, baixe os requerimentos:

```pip install -r "requirements.txt"```

E depois rode no diretório raiz:

```python main.py```